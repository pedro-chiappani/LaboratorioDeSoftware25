public interface Temp {
    void moveHorse(Horse horse, Race race);
}
