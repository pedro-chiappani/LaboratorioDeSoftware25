module HorseRaceSimulation {
    requires java.datatransfer;
    requires java.desktop;
}